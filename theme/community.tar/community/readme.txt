Theme Name: Community
Theme URI: http://theme.sir.co.kr/gnuboard54/demo/community
Maker: SIR
Maker URI: http://sir.kr
Version: 5.4.2.7
Detail: 커뮤니티 테마는  SIR에서 제공하는 그누보드5.4 입니다. 커뮤니티 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html