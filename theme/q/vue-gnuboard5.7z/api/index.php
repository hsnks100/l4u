<?php
include_once('_common.php');
include_once('class.php');
$Vue = new Vue();
echo $Vue->result();
?>