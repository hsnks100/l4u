Theme Name: tailwindadmin
Theme URI: https://allthatnba.com
Maker: Vorfeed
Maker URI: https://allthatnba.com
Version: 0.02
Detail: Tailwind, Swlert2를 활용한 심플한 커뮤니티 테마입니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html